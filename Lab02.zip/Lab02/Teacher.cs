﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab02
{
    internal class Teacher
    {
        public string TLastName { get; set; }
        public string TFirstName { get; set; }
        public int Classroom { get; set; }

        public string ToStringTeacher()
        {
            string data = "TEACHER: " + TLastName + " " + TFirstName + Environment.NewLine;
            return data;
        }
    }
}